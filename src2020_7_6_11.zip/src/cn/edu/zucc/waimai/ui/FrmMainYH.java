package src.cn.edu.zucc.waimai.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import src.cn.edu.zucc.waimai.ui.FrmLogin;


import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.SwingConstants;

import javax.swing.JMenuItem;

public class FrmMainYH extends JFrame {

	private JPanel contentPane;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public FrmMainYH(int a) {
		this.setExtendedState(Frame.MAXIMIZED_BOTH);
		this.setTitle("外卖用户系统");
		
		FrmLogin dLogin = new FrmLogin();
		dLogin.setVisible(true);
		
		
	}
	public FrmMainYH() {
		this.setExtendedState(Frame.MAXIMIZED_BOTH);
		this.setTitle("外卖管理系统");
		
		setBounds(100, 100, 934, 656);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menu_1 = new JMenu("查看订单详情");
		menuBar.add(menu_1);
		
		JMenuItem menuItem_7_1_1 = new JMenuItem("查看所有订单");
		menuItem_7_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		menu_1.add(menuItem_7_1_1);
		
		JMenuItem menuItem_7 = new JMenuItem("已取消的订单");
		menuItem_7.setHorizontalAlignment(SwingConstants.CENTER);
		menu_1.add(menuItem_7);
		
		JMenuItem menuItem_7_1 = new JMenuItem("正在进行的订单");
		menuItem_7_1.setHorizontalAlignment(SwingConstants.CENTER);
		menu_1.add(menuItem_7_1);
		
		JMenuItem menuItem = new JMenuItem("已完成的订单");
		menuItem.setHorizontalAlignment(SwingConstants.CENTER);
		menu_1.add(menuItem);
		
		JMenu menu_6 = new JMenu("管理用户信息");
		menuBar.add(menu_6);
		
		JMenuItem menuItem_1 = new JMenuItem("查看用户信息");
		menuItem_1.setHorizontalAlignment(SwingConstants.CENTER);
		menu_6.add(menuItem_1);
		
		JMenuItem menuItem_5_1 = new JMenuItem("查看会员信息");
		menuItem_5_1.setHorizontalAlignment(SwingConstants.CENTER);
		menu_6.add(menuItem_5_1);
		
		JMenuItem menuItem_2 = new JMenuItem("修改密码");
		menuItem_2.setHorizontalAlignment(SwingConstants.CENTER);
		menu_6.add(menuItem_2);
		menuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrmYHModifyPwd dlg=new FrmYHModifyPwd();
				dlg.setVisible(true);
			}
		});
		
		JMenuItem menuItem_3 = new JMenuItem("修改手机号码");
		menuItem_3.setHorizontalAlignment(SwingConstants.CENTER);
		menu_6.add(menuItem_3);
		menuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrmYHModifyPhonenum dlg=new FrmYHModifyPhonenum();
				dlg.setVisible(true);
			}
		});
		
		JMenuItem menuItem_4 = new JMenuItem("修改邮箱");
		
		menuItem_4.setHorizontalAlignment(SwingConstants.CENTER);
		menu_6.add(menuItem_4);
		
		JMenuItem menuItem_5 = new JMenuItem("修改所在城市");
		menuItem_5.setHorizontalAlignment(SwingConstants.CENTER);
		menu_6.add(menuItem_5);
		
		JMenu menu_5 = new JMenu("管理用户地址");
		menu_5.setHorizontalAlignment(SwingConstants.CENTER);
		menuBar.add(menu_5);
		
		JMenuItem menuItem_9 = new JMenuItem("查看所有地址");
		menuItem_9.setHorizontalAlignment(SwingConstants.CENTER);
		menu_5.add(menuItem_9);
		
		JMenuItem menuItem_9_1 = new JMenuItem("修改省市区");
		menuItem_9_1.setHorizontalAlignment(SwingConstants.CENTER);
		menu_5.add(menuItem_9_1);
		
		JMenuItem menuItem_9_1_1 = new JMenuItem("修改地址");
		menuItem_9_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		menu_5.add(menuItem_9_1_1);
		
		JMenuItem menuItem_9_1_1_1 = new JMenuItem("修改联系人");
		menuItem_9_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		menu_5.add(menuItem_9_1_1_1);
		
		JMenuItem menuItem_9_1_1_1_1 = new JMenuItem("修改电话");
		menuItem_9_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		menu_5.add(menuItem_9_1_1_1_1);
		
		JMenu menu_2 = new JMenu("查看商家");
		menu_2.setHorizontalAlignment(SwingConstants.CENTER);
		menuBar.add(menu_2);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("查看商家详情");
		menu_2.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("查看商品分栏");
		menu_2.add(mntmNewMenuItem_2);
		
		JMenuItem mntmNewMenuItem_2_2 = new JMenuItem("查看商品详情");
		menu_2.add(mntmNewMenuItem_2_2);
		
		JMenuItem mntmNewMenuItem_2_1 = new JMenuItem("查看商家满减方案");
		menu_2.add(mntmNewMenuItem_2_1);
		
		JMenuItem mntmNewMenuItem_2_1_1 = new JMenuItem("查看商家优惠券");
		menu_2.add(mntmNewMenuItem_2_1_1);
		
		JMenuItem mntmNewMenuItem_2_1_1_1 = new JMenuItem("查看商家集单政策");
		menu_2.add(mntmNewMenuItem_2_1_1_1);
		
		JMenu menu_3 = new JMenu("查看持有优惠券");
		menu_3.setHorizontalAlignment(SwingConstants.CENTER);
		menuBar.add(menu_3);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("查看持有优惠券");
		menu_3.add(mntmNewMenuItem_1);
		
		JMenu menu_4 = new JMenu("查看集单进度");
		menu_4.setHorizontalAlignment(SwingConstants.CENTER);
		menuBar.add(menu_4);
		
		JMenuItem mntmNewMenuItem_1_1 = new JMenuItem("查看集单进度");
		menu_4.add(mntmNewMenuItem_1_1);
		
		JMenu menu = new JMenu("购买");
		menuBar.add(menu);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

	}
	
}
