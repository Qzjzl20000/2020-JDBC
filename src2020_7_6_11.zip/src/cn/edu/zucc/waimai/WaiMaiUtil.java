package src.cn.edu.zucc.waimai;

import src.cn.edu.zucc.waimai.comtrol.example.ExampleUserManager;
import src.cn.edu.zucc.waimai.itf.IUserManager;

public class WaiMaiUtil {
	
	public static IUserManager userManager=new ExampleUserManager();//需要换成自行设计的实现类
}
