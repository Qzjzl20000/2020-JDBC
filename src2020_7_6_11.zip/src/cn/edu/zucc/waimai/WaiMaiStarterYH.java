package src.cn.edu.zucc.waimai;


import src.cn.edu.zucc.waimai.ui.FrmMainYH;

public class WaiMaiStarterYH {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FrmMainYH(1);
	}

}
