package src.cn.edu.zucc.waimai.model;


public class BeanUser {
	public static BeanUser currentLoginUser;
	private int User_id;
	private String User_name;
	private int User_sex;
	private String User_pwd;
	private String User_phonenum;
	private String User_email;
	private String user_city;
	private java.sql.Timestamp User_register_time;
	private java.sql.Timestamp User_vip_end_time;

	public int getUser_id() {
		return User_id;
	}
	public void setUser_id(int user_id) {
		User_id = user_id;
	}
	public String getUser_name() {
		return User_name;
	}
	public void setUser_name(String user_name) {
		User_name = user_name;
	}
	public int getUser_sex() {
		return User_sex;
	}
	public void setUser_sex(int user_sex) {
		User_sex = user_sex;
	}
	public String getUser_pwd() {
		return User_pwd;
	}
	public void setUser_pwd(String user_pwd) {
		User_pwd = user_pwd;
	}
	public String getUser_phonenum() {
		return User_phonenum;
	}
	public void setUser_phonenum(String user_phonenum) {
		User_phonenum = user_phonenum;
	}
	public String getUser_email() {
		return User_email;
	}
	public void setUser_email(String user_email) {
		User_email = user_email;
	}
	public String getUser_city() {
		return user_city;
	}
	public void setUser_city(String user_city) {
		this.user_city = user_city;
	}
	public java.sql.Timestamp getUser_register_time() {
		return User_register_time;
	}
	public void setUser_register_time(java.sql.Timestamp user_register_time) {
		User_register_time = user_register_time;
	}
	public java.sql.Timestamp getUser_vip_end_time() {
		return User_vip_end_time;
	}
	public void setUser_vip_end_time(java.sql.Timestamp user_vip_end_time) {
		User_vip_end_time = user_vip_end_time;
	}
	
}
